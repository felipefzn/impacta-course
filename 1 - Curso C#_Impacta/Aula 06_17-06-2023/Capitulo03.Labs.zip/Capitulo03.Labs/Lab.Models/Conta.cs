﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab.Models
{
    public abstract class Conta
    {
        public int NumeroBanco { get; set; }
        public string NumeroAgencia { get; set; }
        public string NumeroConta { get; set; }

        // construtor
        public Conta(int banco, string agencia, string conta)
        {
            NumeroBanco = banco;
            NumeroAgencia = agencia;
            NumeroConta = conta;
        }

        // Metodo que as classes filhas serão obrigadas a
        // fornecer a sua implementação
        public abstract string MostrarExtrato();

    }
}
